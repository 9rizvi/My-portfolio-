import { useEffect, useMemo, useRef, useState, type ReactNode, type CSSProperties } from 'react';
import portrait from './assets/portrait.jpg';
import { motion, useScroll, useTransform, type MotionValue } from 'framer-motion';

/* ---------- Personal details (edit these) ---------- */
const NAME = 'Syed Muhammad Qasim Rizvi';
const WHATSAPP_DISPLAY = '0300-4418952';
const WHATSAPP_LINK = 'https://wa.me/923004418952';

/* ---------- FadeIn ---------- */
type FadeProps = {
  children: ReactNode; delay?: number; duration?: number; x?: number; y?: number;
  className?: string; as?: any; style?: CSSProperties;
};
function FadeIn({ children, delay = 0, duration = 0.7, x = 0, y = 30, className, as = 'div', style }: FadeProps) {
  const M = useMemo(() => motion.create(as), [as]);
  return (
    <M
      className={className}
      style={style}
      initial={{ opacity: 0, x, y }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, margin: '50px', amount: 0 }}
      transition={{ duration, delay, ease: [0.25, 0.1, 0.25, 1] }}
    >
      {children}
    </M>
  );
}

/* ---------- Magnet ---------- */
type MagnetProps = {
  children: ReactNode; padding?: number; strength?: number;
  activeTransition?: string; inactiveTransition?: string; className?: string;
};
function Magnet({
  children, padding = 100, strength = 2,
  activeTransition = 'transform 0.3s ease-out',
  inactiveTransition = 'transform 0.6s ease-in-out', className,
}: MagnetProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!ref.current) return;
      const { left, top, width, height } = ref.current.getBoundingClientRect();
      const cx = left + width / 2, cy = top + height / 2;
      const dx = Math.abs(cx - e.clientX), dy = Math.abs(cy - e.clientY);
      if (dx < width / 2 + padding && dy < height / 2 + padding) {
        setActive(true);
        setPos({ x: (e.clientX - cx) / strength, y: (e.clientY - cy) / strength });
      } else {
        setActive(false);
        setPos({ x: 0, y: 0 });
      }
    };
    window.addEventListener('mousemove', onMove);
    return () => window.removeEventListener('mousemove', onMove);
  }, [padding, strength]);

  return (
    <div ref={ref} className={className} style={{ position: 'relative', display: 'inline-block' }}>
      <div
        style={{
          transform: `translate3d(${pos.x}px, ${pos.y}px, 0)`,
          transition: active ? activeTransition : inactiveTransition,
          willChange: 'transform',
        }}
      >
        {children}
      </div>
    </div>
  );
}

/* ---------- AnimatedText ---------- */
function Char({ ch, progress, range }: { ch: string; progress: MotionValue<number>; range: [number, number] }) {
  const opacity = useTransform(progress, range, [0.2, 1]);
  return (
    <span className="relative inline-block">
      <span className="invisible">{ch}</span>
      <motion.span className="absolute left-0 top-0" style={{ opacity }}>{ch}</motion.span>
    </span>
  );
}
function AnimatedText({ text, className, style }: { text: string; className?: string; style?: CSSProperties }) {
  const ref = useRef<HTMLParagraphElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 0.8', 'end 0.2'] });
  const words = text.split(' ');
  const total = text.length;
  let idx = 0;
  return (
    <p ref={ref} className={className} style={style}>
      {words.map((w, wi) => (
        <span key={wi} className="inline-block whitespace-nowrap">
          {w.split('').map((c, ci) => {
            const start = idx / total;
            const end = start + 1 / total;
            idx++;
            return <Char key={ci} ch={c} progress={scrollYProgress} range={[start, end]} />;
          })}
          {(() => { idx++; return wi < words.length - 1 ? '\u00A0' : null; })()}
        </span>
      ))}
    </p>
  );
}

/* ---------- Buttons ---------- */
function ContactButton() {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noreferrer"
      className="inline-block rounded-full text-white font-medium uppercase tracking-widest px-8 py-3 sm:px-10 sm:py-3.5 md:px-12 md:py-4 text-xs sm:text-sm md:text-base"
      style={{
        background: 'linear-gradient(123deg, #18011F 7%, #B600A8 37%, #7621B0 72%, #BE4C00 100%)',
        boxShadow: '0px 4px 4px rgba(181, 1, 167, 0.25), 4px 4px 12px #7721B1 inset',
        outline: '2px solid white',
        outlineOffset: '-3px',
        border: 'none',
      }}
    >
      Contact Me
    </a>
  );
}
function LiveProjectButton() {
  return (
    <button className="rounded-full border-2 border-[#D7E2EA] text-[#D7E2EA] font-medium uppercase tracking-widest px-8 py-3 sm:px-10 sm:py-3.5 text-sm sm:text-base hover:bg-[#D7E2EA]/10 transition-colors">
      Live Project
    </button>
  );
}

/* ---------- 1. Hero ---------- */
function HeroSection() {
  const links = ['About', 'Experience', 'Projects', 'Contact'];
  return (
    <section className="relative h-screen flex flex-col" style={{ overflowX: 'clip', background: '#0C0C0C' }}>
      <FadeIn delay={0} y={-20}>
        <nav className="flex justify-between px-6 md:px-10 pt-6 md:pt-8">
          {links.map((l) => (
            <a key={l} href={`#${l.toLowerCase()}`}
              className="text-[#D7E2EA] font-medium uppercase tracking-wider text-sm md:text-lg lg:text-[1.4rem] hover:opacity-70 transition-opacity duration-200">
              {l}
            </a>
          ))}
        </nav>
      </FadeIn>

      <div className="overflow-hidden">
        <FadeIn delay={0.15} y={40}>
          <h1 className="hero-heading font-black uppercase tracking-tight leading-none whitespace-nowrap w-full mt-6 sm:mt-4 md:-mt-5 text-[12.5vw] sm:text-[13.5vw] md:text-[14.5vw] lg:text-[16vw]">
            Hi, i&apos;m qasim
          </h1>
        </FadeIn>
      </div>

      <div className="mt-auto flex justify-between items-end px-6 md:px-10 pb-7 sm:pb-8 md:pb-10 relative z-20">
        <FadeIn delay={0.35} y={20}>
          <p className="text-[#D7E2EA] font-light uppercase tracking-wide leading-snug max-w-[160px] sm:max-w-[220px] md:max-w-[260px]"
            style={{ fontSize: 'clamp(0.75rem, 1.4vw, 1.5rem)' }}>
            a software builder and digital marketer crafting reliable systems that help businesses grow
          </p>
        </FadeIn>
        <FadeIn delay={0.5} y={20}><ContactButton /></FadeIn>
      </div>

      <div className="absolute left-1/2 -translate-x-1/2 z-10 top-1/2 -translate-y-1/2 sm:top-auto sm:translate-y-0 sm:bottom-0 w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px]">
        <FadeIn delay={0.6} y={30}>
          <Magnet padding={150} strength={3} activeTransition="transform 0.3s ease-out" inactiveTransition="transform 0.6s ease-in-out" className="w-full">
            <img src={portrait} alt={NAME} className="w-full h-auto max-h-[58vh] object-cover object-top block rounded-t-[32px] sm:rounded-t-[44px] sm:rounded-b-none rounded-b-[32px]"
              style={{ boxShadow: '0 0 80px rgba(118, 33, 176, 0.35)' }} />
          </Magnet>
        </FadeIn>
      </div>
    </section>
  );
}

/* ---------- 2. Marquee ---------- */
type Tile = [string, string];
const ROW1: Tile[] = [
  ['POS Systems', 'Restaurant order management'],
  ['3D Websites', 'Immersive scroll experiences'],
  ['Dispatch', 'Trans Global Services'],
  ['Social Media', 'Content and Meta Ads'],
  ['Lead Tracking', 'CRM workflows'],
  ['Client Management', 'Clear, reliable delivery'],
];
const ROW2: Tile[] = [
  ['Sales Dashboards', 'Daily records and totals'],
  ['Web Development', 'React and Tailwind'],
  ['Freelance', 'Remote client work'],
  ['Logistics', 'On-time coordination'],
  ['Branding', 'Logos and social assets'],
  ['Student Ambassador', 'Community and outreach'],
];

function MarqueeRow({ tiles, offset, dir }: { tiles: Tile[]; offset: number; dir: 1 | -1 }) {
  const tripled = [...tiles, ...tiles, ...tiles];
  return (
    <div className="flex gap-3" style={{ transform: `translateX(${dir * (offset - 200)}px)`, willChange: 'transform' }}>
      {tripled.map(([title, sub], i) => (
        <div key={i} className="rounded-2xl shrink-0 flex flex-col justify-end p-6 border border-[#D7E2EA]/20"
          style={{ width: 420, height: 270, background: 'linear-gradient(135deg, #18011F 0%, #2B0B3D 60%, #3A1250 100%)' }}>
          <span className="hero-heading font-black uppercase leading-none" style={{ fontSize: '2.2rem' }}>{title}</span>
          <span className="text-[#D7E2EA] font-light uppercase tracking-wide mt-2 text-sm">{sub}</span>
        </div>
      ))}
    </div>
  );
}
function MarqueeSection() {
  const ref = useRef<HTMLElement>(null);
  const [offset, setOffset] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      if (!ref.current) return;
      const top = ref.current.getBoundingClientRect().top + window.scrollY;
      setOffset((window.scrollY - top + window.innerHeight) * 0.3);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <section ref={ref} className="pt-24 sm:pt-32 md:pt-40 pb-10 flex flex-col gap-3" style={{ background: '#0C0C0C', overflowX: 'clip' }}>
      <MarqueeRow tiles={ROW1} offset={offset} dir={1} />
      <MarqueeRow tiles={ROW2} offset={offset} dir={-1} />
    </section>
  );
}

/* ---------- 3. About ---------- */
function AboutSection() {
  return (
    <section id="about" className="relative min-h-screen flex flex-col items-center justify-center px-5 sm:px-8 md:px-10 py-20 gap-16 sm:gap-20 md:gap-24" style={{ background: '#0C0C0C' }}>
      <div className="flex flex-col items-center gap-10 sm:gap-14 md:gap-16 relative z-10">
        <FadeIn delay={0} y={40}>
          <h2 className="hero-heading font-black uppercase leading-none tracking-tight text-center" style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}>
            About me
          </h2>
        </FadeIn>
        <AnimatedText
          text="I am a Lahore-based software developer and digital marketer with one year of professional experience in logistics dispatch at Trans Global Services, complemented by freelance work in point-of-sale systems, website development, and social media management. I translate real operational challenges into dependable digital solutions, and I am eager to represent and connect my peers as a Student Ambassador. Let's build something incredible together!"
          className="text-[#D7E2EA] font-medium text-center leading-relaxed max-w-[560px]"
          style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}
        />
      </div>
      <div className="relative z-10"><ContactButton /></div>
    </section>
  );
}

/* ---------- 4. Services ---------- */
const SERVICES = [
  ['Dispatch Operations', 'Trans Global Services (1 year): coordinating loads, drivers, and schedules with precision, maintaining clear communication and ensuring dependable, on-time delivery.'],
  ['POS Systems', 'Freelance: designing and building point-of-sale and order-management software for restaurants, with live sales dashboards, stock tracking, and daily records.'],
  ['Web Development', 'Freelance: developing modern, responsive, conversion-focused websites, including immersive 3D experiences, with careful attention to layout and usability.'],
  ['Social Media Management', 'Freelance: planning content, managing Meta Ads, and tracking leads through a CRM to grow brand visibility and generate qualified enquiries.'],
  ['Client Management', 'Freelance: maintaining strong client relationships through clear communication, structured workflows, and consistently professional delivery.'],
];
function ServicesSection() {
  return (
    <section id="experience" className="rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32" style={{ background: '#FFFFFF' }}>
      <h2 className="font-black uppercase text-center mb-16 sm:mb-20 md:mb-28" style={{ color: '#0C0C0C', fontSize: 'clamp(3rem, 12vw, 160px)', lineHeight: 1 }}>
        Experience
      </h2>
      <div className="max-w-5xl mx-auto">
        {SERVICES.map(([name, desc], i) => (
          <FadeIn key={name} delay={i * 0.1}
            className="flex items-start gap-6 sm:gap-10 py-8 sm:py-10 md:py-12"
            style={{ borderTop: i === 0 ? undefined : '1px solid rgba(12, 12, 12, 0.15)', color: '#0C0C0C' }}>
            <span className="font-black leading-none" style={{ fontSize: 'clamp(3rem, 10vw, 140px)', color: '#0C0C0C' }}>
              {String(i + 1).padStart(2, '0')}
            </span>
            <div className="flex flex-col gap-2">
              <h3 className="font-medium uppercase" style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)' }}>{name}</h3>
              <p className="font-light leading-relaxed max-w-2xl" style={{ fontSize: 'clamp(0.85rem, 1.6vw, 1.25rem)', opacity: 0.6 }}>{desc}</p>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}

/* ---------- 5. Projects ---------- */
type Project = { name: string; cat: string; tags: string[]; live: boolean; imgs?: string[] };
// To use real screenshots, add imgs: [leftTop, leftBottom, right] (URLs or imported files) to a project.
const PROJECTS: Project[] = [
  { name: 'Restaurant POS System', cat: 'Freelance', live: true,
    tags: ['Tap-to-order menu', 'Daily sales dashboard', 'Date-wise records', 'Stock and rates'] },
  { name: 'Restaurant 3D Website', cat: 'Freelance', live: true,
    tags: ['3D scroll experience', 'Full menu', 'WhatsApp orders', 'Responsive design'] },
  { name: 'Dispatch Operations', cat: 'Trans Global Services', live: false,
    tags: ['1 year experience', 'Load coordination', 'Driver communication', 'On-time delivery'] },
];
const R = 'rounded-[40px] sm:rounded-[50px] md:rounded-[60px]';

function ProjectCard({ p, index, total }: { p: Project; index: number; total: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'start start'] });
  const targetScale = 1 - (total - 1 - index) * 0.03;
  const scale = useTransform(scrollYProgress, [0, 1], [1, targetScale]);
  const slot = (i: number, lines: string[], style: CSSProperties, big = false) =>
    p.imgs?.[i] ? (
      <img src={p.imgs[i]} alt="" loading="lazy" className={`w-full object-cover ${R}`} style={style} />
    ) : (
      <div className={`w-full flex flex-col items-center justify-center text-center gap-2 p-4 ${R}`}
        style={{ ...style, background: 'linear-gradient(135deg, #18011F 0%, #2B0B3D 60%, #3A1250 100%)' }}>
        {lines.map((l, k) => (
          <span key={k} className={k === 0 && big ? 'hero-heading font-black uppercase leading-tight' : 'text-[#D7E2EA] font-light uppercase tracking-wide'}
            style={{ fontSize: k === 0 && big ? 'clamp(1.2rem, 3vw, 2.6rem)' : 'clamp(0.7rem, 1.4vw, 1.2rem)' }}>{l}</span>
        ))}
      </div>
    );
  return (
    <div ref={ref} className="h-[85vh]">
      <div className="sticky top-24 md:top-32">
        <motion.div
          className={`border-2 border-[#D7E2EA] p-4 sm:p-6 md:p-8 ${R}`}
          style={{ background: '#0C0C0C', scale, top: index * 28, position: 'relative', transformOrigin: 'top center' }}
        >
          <div className="flex items-center justify-between gap-4 mb-4 sm:mb-6">
            <div className="flex items-center gap-4 sm:gap-8 min-w-0">
              <span className="hero-heading font-black leading-none" style={{ fontSize: 'clamp(3rem, 10vw, 140px)' }}>
                {String(index + 1).padStart(2, '0')}
              </span>
              <div className="flex flex-col">
                <span className="text-[#D7E2EA] font-light uppercase tracking-wide opacity-60 text-xs sm:text-base">{p.cat}</span>
                <span className="text-[#D7E2EA] font-medium uppercase" style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)' }}>{p.name}</span>
              </div>
            </div>
            {p.live && <div className="hidden sm:block"><LiveProjectButton /></div>}
          </div>
          <div className="flex gap-3 sm:gap-4">
            <div className="flex flex-col gap-3 sm:gap-4" style={{ width: '40%' }}>
              {slot(0, [p.tags[0]], { height: 'clamp(130px, 16vw, 230px)' })}
              {slot(1, [p.tags[1]], { height: 'clamp(160px, 22vw, 340px)' })}
            </div>
            <div style={{ width: '60%' }}>
              {slot(2, [p.name, p.tags[2], p.tags[3]], { height: '100%' }, true)}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
function ProjectsSection() {
  return (
    <section id="projects" className="relative z-10 -mt-10 sm:-mt-12 md:-mt-14 rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32" style={{ background: '#0C0C0C' }}>
      <h2 className="hero-heading font-black uppercase leading-none tracking-tight text-center mb-16 sm:mb-20 md:mb-28" style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}>
        Project
      </h2>
      {PROJECTS.map((p, i) => <ProjectCard key={p.name} p={p} index={i} total={PROJECTS.length} />)}
    </section>
  );
}

/* ---------- 6. Contact ---------- */
function ContactSection() {
  return (
    <section id="contact" className="px-5 sm:px-8 md:px-10 pt-10 pb-16 flex flex-col items-center gap-10 text-center" style={{ background: '#0C0C0C' }}>
      <FadeIn>
        <h2 className="hero-heading font-black uppercase leading-none tracking-tight" style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}>
          Contact
        </h2>
      </FadeIn>
      <FadeIn delay={0.1}>
        <p className="text-[#D7E2EA] font-medium" style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}>
          {NAME} &middot; Lahore, Pakistan &middot; WhatsApp {WHATSAPP_DISPLAY}
        </p>
      </FadeIn>
      <FadeIn delay={0.2}><ContactButton /></FadeIn>
      <p className="text-[#D7E2EA] font-light opacity-50 text-sm">&copy; {new Date().getFullYear()} {NAME}</p>
    </section>
  );
}

/* ---------- App ---------- */
export default function App() {
  return (
    <main style={{ background: '#0C0C0C', overflowX: 'clip' }}>
      <HeroSection />
      <MarqueeSection />
      <AboutSection />
      <ServicesSection />
      <ProjectsSection />
      <ContactSection />
    </main>
  );
}
